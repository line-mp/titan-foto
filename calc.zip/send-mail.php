<?php
// ============================================================
// send-mail.php — обработчик заявок калькулятора Фабрики Свай
// Кладётся в КОРЕНЬ сайта (рядом с wp-config.php)
// v4: заголовки блоков с ━━━ разделителями
// ============================================================

if ($_SERVER["REQUEST_METHOD"] !== "POST") {
    echo "error: Неверный метод запроса";
    exit;
}

if (empty($_POST['name']) || empty($_POST['phone'])) {
    die('Ошибка: заполните обязательные поля');
}
if (!empty($_POST['honeypot'])) {
    die('Спам заблокирован');
}

$name    = htmlspecialchars(trim($_POST['name']));
$phone   = htmlspecialchars(trim($_POST['phone']));
$address = htmlspecialchars(trim($_POST['address'] ?? ''));

$object_type = htmlspecialchars($_POST['object_type'] ?? '');
$object_size = htmlspecialchars($_POST['object_size'] ?? '');
$soil        = htmlspecialchars($_POST['soil'] ?? '');
$floors      = htmlspecialchars($_POST['floors'] ?? '');
$has_stove   = htmlspecialchars($_POST['has_stove'] ?? '');

$pile_type         = htmlspecialchars($_POST['pile_type'] ?? '');
$pile_length       = htmlspecialchars($_POST['pile_length'] ?? '');
$pile_count        = htmlspecialchars($_POST['pile_count'] ?? '');
$head_type         = htmlspecialchars($_POST['head_type'] ?? '');
$mounting_type     = htmlspecialchars($_POST['mounting_type'] ?? '');
$delivery_distance = htmlspecialchars($_POST['delivery_distance'] ?? '');
$binding_type      = htmlspecialchars($_POST['binding_type'] ?? '');
$binding_length    = htmlspecialchars($_POST['binding_length'] ?? '');

$material_cost = htmlspecialchars($_POST['material_cost'] ?? '');
$head_cost     = htmlspecialchars($_POST['head_cost'] ?? '');
$mounting_cost = htmlspecialchars($_POST['mounting_cost'] ?? '');
$delivery_cost = htmlspecialchars($_POST['delivery_cost'] ?? '');
$binding_cost  = htmlspecialchars($_POST['binding_cost'] ?? '');
$total_cost    = htmlspecialchars($_POST['total_cost'] ?? '');

// ============================================================
// Email получателя — ПОМЕНЯЙ на реальный
// ============================================================
$to = "info@fabrika-svai.ru";

// Тема, закодированная в Base64 для Яндекса
$subject_raw = "Заявка с калькулятора";
$subject = "=?UTF-8?B?" . base64_encode($subject_raw) . "?=";

// ============================================================
// Тело письма — с ━━━ разделителями
// ============================================================
$message  = "Заявка с калькулятора Фабрики Свай\n\n";

$message .= "━━━ Контакты ━━━\n";
$message .= "Имя: $name\n";
$message .= "Телефон: $phone\n";
if (!empty($address)) {
    $message .= "Адрес: $address\n";
}
$message .= "\n";

$message .= "━━━ Объект ━━━\n";
if (!empty($object_type)) $message .= "Тип: $object_type\n";
if (!empty($object_size)) $message .= "Размер: $object_size\n";
if (!empty($floors))      $message .= "Этажность: $floors\n";
if (!empty($soil))        $message .= "Грунт: $soil\n";
if (!empty($has_stove))   $message .= "Печь / камин: $has_stove\n";
$message .= "\n";

$message .= "━━━ Параметры расчёта ━━━\n";
$message .= "Тип сваи: $pile_type\n";
$message .= "Длина сваи: $pile_length\n";
$message .= "Количество свай: $pile_count шт\n";
$message .= "Тип оголовка: $head_type\n";
$message .= "Тип монтажа: $mounting_type\n";
$message .= "Тип обвязки: $binding_type\n";
if (!empty($binding_length) && $binding_length > 0) {
    $message .= "Длина обвязки: $binding_length м\n";
}
$message .= "Расстояние: $delivery_distance км от СПб\n";
$message .= "\n";

$message .= "━━━ Смета ━━━\n";
$message .= "Сваи (материал): $material_cost\n";
$message .= "Оголовки: $head_cost\n";
$message .= "Монтаж: $mounting_cost\n";
$message .= "Обвязка: $binding_cost\n";
$message .= "Доставка: $delivery_cost\n";
$message .= "\n";
$message .= "ИТОГО: $total_cost\n";
$message .= "\n";

$message .= "━━━ Служебное ━━━\n";
$message .= "Дата: " . date('d.m.Y H:i:s') . "\n";
$message .= "IP: " . ($_SERVER['REMOTE_ADDR'] ?? 'unknown') . "\n";
$message .= "Страница: " . ($_SERVER['HTTP_REFERER'] ?? 'прямой заход') . "\n";

// Заголовки
$host = $_SERVER['HTTP_HOST'] ?? 'fabrika-svai.ru';
$headers  = "From: no-reply@$host\r\n";
$headers .= "Reply-To: no-reply@$host\r\n";
$headers .= "Content-Type: text/plain; charset=utf-8\r\n";
$headers .= "MIME-Version: 1.0\r\n";
$headers .= "X-Mailer: PHP/" . phpversion();

if (mail($to, $subject, $message, $headers)) {
    echo "success: Заявка успешно отправлена!";
} else {
    echo "error: Ошибка при отправке. Свяжитесь с нами по телефону.";
}
?>
